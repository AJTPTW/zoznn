// ==UserScript==
// @name         V2EX链接移除楼层标签锚
// @namespace    http://zhangbohun.github.io/
// @version      0.2
// @description  V2EX链接移除楼层标签锚（避免干扰判断是否已经收藏夹）
// @author       zhangbohun
// @match        *://*.v2ex.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    document.querySelectorAll('a').forEach(function(element){if(element.href.indexOf('v2ex.com/t/')!=-1){element.href=element.href.split('#')[0]}});
})();
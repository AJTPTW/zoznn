// ==UserScript==
// @name         Instagram: Download Photo & Video
// @description  Download photo or video by one button click.
// @namespace	 https://github.com/HayaoGai
// @version      1.0.5
// @author       Hayao-Gai
// @match        https://www.instagram.com/*
// @grant        none
// ==/UserScript==

/* jshint esversion: 6 */

(function() {
    'use strict';

    const imgDownload = "https://i.imgur.com/NNpZm8Q.png";
    const imgNewTab = "https://i.imgur.com/XL5EnSJ.png";
    let observer;

    window.onload = () => {
        detectAddress();
        condition();
    };

    function detectAddress() {
        window.addEventListener('locationchange', () => {
            for (let i = 0; i < 10; i++) {
                setTimeout(condition, 500 * i);
            }
        });
        history.pushState = (f => function pushState(){
            var ret = f.apply(this, arguments);
            window.dispatchEvent(new Event('pushState'));
            window.dispatchEvent(new Event('locationchange'));
            return ret;
        })(history.pushState);
        history.replaceState = (f => function replaceState(){
            var ret = f.apply(this, arguments);
            window.dispatchEvent(new Event('replaceState'));
            window.dispatchEvent(new Event('locationchange'));
            return ret;
        })(history.replaceState);
        window.addEventListener('popstate', () => {
            window.dispatchEvent(new Event('locationchange'));
        });
    }

    function condition() {
        // reset observer.
        if (!!observer) observer.disconnect();
        // detect current page is personal news feed or not.
        if (document.querySelectorAll(".wmtNn").length > 1) setObserver();
        // add a download button if not exist.
        addButton();
    }

    function setObserver() {
		const MutationObserver = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver;
		observer = new MutationObserver(addButton);
		const config = { attributes: true };
		const panel = document.querySelector("article").parentElement;
        if (!!panel) observer.observe(panel, config);
	}

    function addButton() {
        document.querySelectorAll(".wmtNn").forEach(wmtNn => {
            if (!wmtNn.previousSibling.className.includes("download")) {
                buttonDetail(wmtNn, true);
                buttonDetail(wmtNn, false);
            }
        });
    }

    function buttonDetail(lastElement, isDownload) {
        // firefox doesn't support direct download function.
        if (isDownload) {
            const isFirefox = typeof InstallTrigger !== 'undefined';
            if (isFirefox) return;
        }
        // create
        const outside = document.createElement("span");
        outside.classList.add("download");
        const middle = document.createElement("button");
        middle.classList.add("dCJp8");
        middle.classList.add("afkep");
        const inside = document.createElement("img");
        inside.src = isDownload ? imgDownload : imgNewTab;
        // append
        middle.appendChild(inside);
        outside.appendChild(middle);
        lastElement.before(outside);
        // event
        middle.addEventListener("click", function() {
            const parent = this.closest(".eo2As").previousElementSibling;
            // a page panel under photo or video, it means there is only one photo or video if not exist.
            const isSingle = !parent.querySelectorAll("._3eoV-.IjCL9").length;
            const files = parent.querySelectorAll(".FFVAD").length ? parent.querySelectorAll(".FFVAD") : parent.querySelectorAll("video");
            const link = isSingle ? files[0].src : detectPosition(parent, files);
            download(link, isDownload);
        });
    }

    function download(link, isDownload) {
        if (isDownload) {
            fetch(link).then(t => {
                return t.blob().then(b => {
                    const a = document.createElement("a");
                    a.href = URL.createObjectURL(b);
                    a.setAttribute("download", getTime());
                    a.click();
                });
            });
        } else {
            const tab = window.open(link, '_blank');
            tab.focus();
        }
    }

    function detectPosition(parent, files) {
        // detect position by 2 dynamic arrow buttons on the view panel.
        const next = parent.querySelectorAll("._6CZji").length;
        const previous = parent.querySelectorAll(".POSa_").length;
        // first
        if (!!next && !previous) return files[0].src;
        // middle || end
        else return files[1].src;
    }

    function getTime() {
        const date = new Date();
        const year = date.getFullYear();
        const month = addZero(date.getMonth() + 1);
        const day = addZero(date.getDate());
        const hour = addZero(date.getHours());
        const minute = addZero(date.getMinutes());
        const second = addZero(date.getSeconds());
        return `${year}${month}${day}${hour}${minute}${second}`;
    }

    function addZero(value) {
        return value < 10 ? `0${value}` : `${value}`;
    }
})();
// ==UserScript==
// @name         居中 页面 对齐
// @namespace    http://tampermonkey.net/
// @version      0.4
// @description   居中 页面 按钮 简陋的 center page web button rough
// @author        批小将
// @match         *://*/*
// @grant         none
// ==/UserScript==

(function() {
    'use strict';
    if (window.top === window.self){
        let btn = document.createElement('button');
        btn.style.cssText = 'position: absolute; right: 0; top: 0; font-size: 15px; padding: 2px; border: 1px solid black; z-index: 99999';
        let textnode = document.createTextNode('center');
        btn.appendChild(textnode);
        let body = document.getElementsByTagName('body')[0];
        body.prepend(btn);

        btn.addEventListener('click', function(){
            //这里修改宽度，720px;
            let centercss = 'width: fit-content; margin: 0 auto; max-width: 720px;';
            body.setAttribute('style', centercss);
        });
    }
})();
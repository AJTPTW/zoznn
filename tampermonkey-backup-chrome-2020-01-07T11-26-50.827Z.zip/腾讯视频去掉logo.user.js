// ==UserScript==
// @name         腾讯视频去掉logo
// @namespace    http://tampermonkey.net/
// @version      0.2
// @description  try to take over the world!
// @author       pobc
// @license      GPL License
// @match             *://v.qq.com/x/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    window.hideLogTryTimes = 0;
    waitForElementToDisplay('.txp_waterMark_pic',2000);
    // Your code here...
})();


function waitForElementToDisplay(selector, time) {
    if(document.querySelector(selector)!=null ||window.hideLogTryTimes>=3) {
        document.querySelectorAll(".txp_waterMark_pic").forEach(function(item,index,arr){item.style.display='none';});
        return;
    }
    else {
        window.hideLogTryTimes++;
        setTimeout(function() {
            waitForElementToDisplay(selector, time);
        }, time);
    }
}